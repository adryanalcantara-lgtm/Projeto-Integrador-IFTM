#include <bits/stdc++.h>
using namespace std;
vector<int> abrir(int controle[0]){
   vector<int> pac(3);
    pac[0] = rand() % 20;
        controle[pac[0]]++;
    pac[1] = rand() % 20;
        controle[pac[1]]++;
    pac[2] = rand() % 20;
        controle[pac[2]]++;
    return pac;
}
void dados(int i, string nomejogador[] ,string posicaojogador[], string infojogadoralt[], double infojogadorpes[], string nascerjogador[]){
    cout<<nomejogador[i]<<"\n";
    cout<<"Posição: "<<posicaojogador[i]<<"\n";
    cout<<"Altura: "<<infojogadoralt[i]<<" m"<<"\n";
    cout<<"Peso: "<<infojogadorpes[i]<<" kg"<<"\n";
    cout<<"Data de nascimento:"<<nascerjogador[i]<<"\n"<<"\n";
    
}
void menu(){
        cout<<"                                                    Album do Paraguai"<<"\n";
        cout<<"1. Para visualizar Elenco"<<"\n";
        cout<<"2. Abrir Pacote de Figurinhas"<<"\n";
        cout<<"3. Visualizar Status do Álbum"<<"\n";
        cout<<"4. Ver Figurinhas Repetidas"<<"\n";
        cout<<"5. Busca por nome jogador"<<"\n";
        cout<<"6. Busca por posição do jogador"<<"\n";
        cout<<"7. Sair"<<"\n"<<"\n";
}
vector<int> buscap(string posicao,string posicaojogador[]){
    vector<int> encontrados;
        for(int i=0;i<20;i++){
            if(posicaojogador[i]==posicao){
                encontrados.push_back(i);
        }
    }
    return encontrados;
}
vector<int> buscan(string nome, string nomejogador[]){
    vector<int> encontrados;
        for(int i = 0; i < 20; i++){
            if(nomejogador[i].find(nome) != -1){
                encontrados.push_back(i);
            }
    }
    return encontrados;
}
    int main(){
    string nomejogador[20]={
    "Carlos Coronel","Gatito Fernández","Gustavo Gómez","Omar Alderete","Junior Alonso",
    "Fabián Balbuena","Juan Cáceres","Agustín Sández","Mathías Villasanti","Damián Bobadilla","Andrés Cubas","Diego Gómez",
    "Alejandro Romero","Miguel Almirón","Julio Enciso","Ramón Sosa","Ángel Romero","Antonio Sanabria","Alex Arce",
    "Isidro Pitta"};
    
    string posicaojogador[20]={
    "goleiro", "goleiro", "defensor", "defensor", "defensor",
    "defensor", "defensor", "defensor", "meio campista", "meio campista",
    "meio campista", "meio campista", "meio campista", "atacante", "atacante",
    "atacante", "atacante", "atacante", "atacante", "atacante"};
    
    string infojogadoralt[20]={
    "1,88", "1,91", "1,85", "1,88", "1,85", "1,88", "1,78", "1,83", "1,78",
    "1,81", "1,63", "1,85", "1,73","1,74", "1,73", "1,78", "1,77", "1,81", "1,87", "1,83"};
    
    double infojogadorpes[20]={
    88, 87, 85, 80, 82, 82, 74, 78, 73, 75,
    60, 79, 68, 67, 64, 74, 72, 78, 82, 80};
    
    string nascerjogador[20]={
    "29/12/1996","29/03/1988","06/05/1993","26/12/1996","09/02/1993","23/08/1991","01/06/2000",
    "16/01/2001","24/01/1997","11/07/2001","22/05/1996","27/03/2003","11/01/1995","10/02/1994",
    "23/01/2004","31/08/1999","04/07/1992","04/03/1996","19/05/1995","14/08/1999"
    };
    int controle[20]={0};
    int escolha;
    do{ 
    if(controle[0]>0&&controle[1]>0&&controle[2]>0&&controle[3]>0&&controle[4]>0&&controle[5]>0&&controle[6]>0&&
    controle[7]>0&&controle[8]>0&&controle[9]>0&&controle[10]>0&&controle[11]>0&&controle[12]>0&&
    controle[13]>14&&controle[15]>0&&controle[16]>0&&controle[17]>0&&controle[18]>0&&controle[19]>0){
        cout<<"Completou o Albúm, corra daqui."<<endl;
        for(int i=0;i<20;i++){
            dados(i, nomejogador, posicaojogador, infojogadoralt, infojogadorpes, nascerjogador);
        }
        return 0;
    }
    menu();
    cin>>escolha;
    switch(escolha){
    case 1:{
        system("clear");
        cout<<"O Elenco"<<"\n";
        int i=0;
        for(int i=0;i<20;i++){
            dados(i, nomejogador, posicaojogador, infojogadoralt, infojogadorpes, nascerjogador);
        }
        break;
    }
    case 2:{
        system("clear");
        cout<<"Abertura de Pacotinhos"<<"\n";
        vector<int> pac = abrir(controle);
        for(int i = 0; i < 3; i++){
                    dados(pac[i], nomejogador, posicaojogador, infojogadoralt, infojogadorpes, nascerjogador);
                }
        break;
    }
    
    case 3:{
        system("clear");
        cout<<"Figurinhas Obtidas"<<"\n";
        for(int i = 0; i < 20; i++){
        if(controle[i] > 0){
                dados(i, nomejogador, posicaojogador, infojogadoralt, infojogadorpes, nascerjogador);
            }
        }
        break;
    }
    case 4:{
        system("clear");
        cout << "Figurinhas Repetidas\n";
                for(int i = 0; i < 20; i++){
                    if(controle[i] > 1){
                        dados(i, nomejogador, posicaojogador, infojogadoralt, infojogadorpes, nascerjogador);
                        cout << "Quantidade repetida: " << controle[i] - 1 << "\n";
                    }
                }
                break;}
    case 5:{
        system("clear");
        cout<<"Escreva qual o nome do jogador que voce quer procurar";
        string nome;
        cin.ignore();
        getline(cin, nome);
        vector<int> encontrados = buscan(nome, nomejogador);
        for(int i=0;i<encontrados.size();i++){
            dados(encontrados[i], nomejogador, posicaojogador, infojogadoralt, infojogadorpes, nascerjogador);
        }
        break;}
    
    case 6:{
        system("clear");
        string posicao;
        cout<<"Escreva qual posicao que voce quer procurar, em minusculo ";
        cin>>posicao;
        vector<int> encontrados = buscap(posicao, posicaojogador);
        for(int i=0;i<encontrados.size();i++){
            dados(encontrados[i], nomejogador, posicaojogador, infojogadoralt, infojogadorpes, nascerjogador);
        }
        break;
    }
    case 7:{
        system("clear");
        cout<<"volte já";
        return 0;
    }
    }}while(escolha!=7);
    return 0;
}
